<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Syarat & Ketentuan</title>
    <!-- Font Icon -->
    <link rel="stylesheet" href="assets/fonts/material-icon/css/material-design-iconic-font.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>
    <div class="container mt-5">
        <!-- Sign up form -->
        <section class="signup">
            <div class="container">
                <div class="signup-content">
                    <div class="signup-form">
                        <h2 class="form-title">Syarat & Ketentuan</h2>
                        <p>Selamat datang di <b>Love Wedding Invitation</b></p>
                        <p>Disarankan sebelum mengakses dan menggunakan jasa Web App ini lebih jauh. Anda terlebih dahulu membaca dan memahami syarat dan ketentuan yang berlaku. Syarat dan ketentuan berikut adalah ketentuan dalam pengguna atau pengunjung situs, isi dan/atau konten, layanan, serta fitur lainnya yang ada di <b>www.love-weddinginvitation.com</b>. Dengan mengakses atau menggunakan situs <b>www.love-weddinginvitation.com</b>, informasi, atau aplikasi lainnya dalam bentuk mobile application yang disediakan oleh atau dalam situs, berarti anda telah memahami dan menyetujui serta terikat dan tunduk dengan segala syarat dan ketentuan yang berlaku di situs ini.</p>
                        <p>Hasil desain undangan yang telah dipesan di situs ini dapat digunakan sebagai media promosi/portfolio oleh <b>www.love-weddinginvitation.com</b> tanpa meminta persetujuan pemesan undangan terlebih dahulu.</p>
                        <p>Acara kami berhak menghapus data/desain undangan yang telah dibuat lebih dari 365 hari (1 Tahun) dihitung dari tanggal online pertama kali tanpa meminta persetujuan pemesan undangan terlebih dahulu.</p>
                        <p>Proses persetujuan login jika sudah melakukan pembayaran dan register akan di proses 1x24 jam setelah register dilakukan.</p>
                        <p>Dana yang telah dibayarkan untuk undangan tidak dapat di refund dengan alasan apapun.</p>
                        <p>Syarat, ketentuan & harga undangan dapat berubah sewaktu-waktu tanpa pemberitahuan terlebih dahulu.</p>

                    </div>
                    <div class="signup-image">
                        <a href="login.php" class="signup-image-link">I am already member</a>
                        <a href="register.php" class="link-dark signup-image-link">Sign Up / Register</a><br>
                        <figure><img src="assets/images/logos.png" width="50%" alt="sing up image"></figure>
                        <a href="" class="link-dark signup-image-link">Lihat Contoh Undangan</a><br>
                        <a href="testimoni.php" class="link-dark signup-image-link">Testimoni</a><br>
                        <a href="blog.php" class="link-dark signup-image-link">Blog</a><br>
                        <a href="tentang_kami.php" class="link-dark signup-image-link">Tentang Kami</a><br>
                        <a href="cara_pembayaran.php" class="link-dark signup-image-link">Cara Pembayaran</a><br>
                        <a href="faq_bantuan.php" class="link-dark signup-image-link">FAQ / Pusat Bantuan</a><br>
                        <a href="syarat_ketentuan.php" class="link-dark signup-image-link">Syarat & Ketentuan</a><br>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <!-- JS -->
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/js/main.js"></script>
    <!-- Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>

</html>