<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FAQ / Pusat Bantuan</title>
    <!-- Font Icon -->
    <link rel="stylesheet" href="assets/fonts/material-icon/css/material-design-iconic-font.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>
    <div class="container mt-5">
        <!-- Sign up form -->
        <section class="signup">
            <div class="container">
                <div class="signup-content">
                    <div class="signup-form">
                        <h2 class="form-title">FAQ / Pusat Bantuan</h2>
                        <p>Kami senang dapat memandu anda untuk membagikan momen bahagia anda dengan cara yang lebih mudah. Hubungi kami jika mengalami kendala, kami akan selalu ada untuk anda, kontak kami di <a href="mailto:hi-love@loveweddinginvitation.com">hi-love@loveweddinginvitation.com</a> / (WhatsApp) <a href="http://api.whatsapp/send?phone=6281339164660&text=Hi, Pusat Bantuan Love Invitation Saya butuh bantuan.">081339164660</a></p>
                        <div class="accordion" id="accordionExample">
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingOne">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                        Kenapa kok nggak bisa login?
                                    </button>
                                </h2>
                                <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p>Sebelum anda melakukan login, terlebih dahulu anda harus melakukan pembayaran dan register dengan mengupload bukti transfer bank.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingTwo">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                        Udah bayar dan register kok nggak bisa login?
                                    </button>
                                </h2>
                                <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p>Pastikan username dan password yang anda daftarkan sudah benar atau anda bisa (WhatsApp) ke nomor ini <a href="http://api.whatsapp/send?phone=6281339164660&text=Hi, Pusat Bantuan Love Invitation Saya butuh bantuan.">081339164660</a></p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingThree">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                        Apakah ada batasan revisi?
                                    </button>
                                </h2>
                                <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p>Tidak ada batasan revisi untuk setiap akun, anda bisa melakukan senidri revisi kata-kata,nama, lokasi, foto, video, tanggal, musik dan semua fitur yang sudah anda dapatkan pada menu dashboard.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="signup-image">
                        <a href="login.php" class="signup-image-link">I am already member</a>
                        <a href="register.php" class="link-dark signup-image-link">Sign Up / Register</a><br>
                        <figure><img src="assets/images/logos.png" width="50%" alt="sing up image"></figure>
                        <a href="" class="link-dark signup-image-link">Lihat Contoh Undangan</a><br>
                        <a href="testimoni.php" class="link-dark signup-image-link">Testimoni</a><br>
                        <a href="blog.php" class="link-dark signup-image-link">Blog</a><br>
                        <a href="tentang_kami.php" class="link-dark signup-image-link">Tentang Kami</a><br>
                        <a href="cara_pembayaran.php" class="link-dark signup-image-link">Cara Pembayaran</a><br>
                        <a href="faq_bantuan.php" class="link-dark signup-image-link">FAQ / Pusat Bantuan</a><br>
                        <a href="syarat_ketentuan.php" class="link-dark signup-image-link">Syarat & Ketentuan</a><br>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <!-- JS -->
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/js/main.js"></script>
    <!-- Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>

</html>